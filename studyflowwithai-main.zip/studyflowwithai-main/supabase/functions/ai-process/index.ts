import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { content, type } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    let systemPrompt = "";
    if (type === "notes") {
      systemPrompt = `You are an expert study note generator. Given the following study material, create comprehensive, well-structured Markdown notes with:
- Clear headings and subheadings
- Bullet points for key concepts
- Tables where appropriate
- Code blocks if technical content is detected
- Bold for important terms
- Numbered lists for sequential processes
Keep notes thorough but organized. Use ## for main sections, ### for subsections.`;
    } else if (type === "summary") {
      systemPrompt = `You are an expert summarizer. Create a concise 300-600 word summary of the following study material. Focus on:
- Main themes and arguments
- Key takeaways
- Important relationships between concepts
- Practical implications
Write in clear, accessible prose.`;
    } else if (type === "quiz") {
      systemPrompt = `You are an expert quiz creator. Generate 12-20 quiz questions from the following material. Return a JSON array where each question object has:
- "question": the question text
- "type": "multiple_choice", "true_false", or "short_answer"
- "options": array of options (for multiple_choice, 4 options; for true_false, ["True", "False"]; for short_answer, empty array)
- "correct_answer": the correct answer text
- "explanation": brief explanation of why this is correct

Return ONLY the JSON array, no other text.`;
    } else if (type === "chat") {
      systemPrompt = `You are a warm, patient, encouraging AI study tutor. You help students understand concepts from their study materials. 
- Break down complex ideas simply
- Use analogies and mnemonics
- Ask follow-up questions to check understanding
- Be supportive and motivating
- If asked to quiz, create practice questions
Keep responses concise but thorough.`;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...(Array.isArray(content) ? content : [{ role: "user", content }]),
        ],
        stream: type === "chat",
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI usage limit reached. Please add credits." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI error:", response.status, t);
      throw new Error("AI processing failed");
    }

    if (type === "chat") {
      return new Response(response.body, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
      });
    }

    const data = await response.json();
    const result = data.choices?.[0]?.message?.content || "";

    return new Response(JSON.stringify({ result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("Error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
