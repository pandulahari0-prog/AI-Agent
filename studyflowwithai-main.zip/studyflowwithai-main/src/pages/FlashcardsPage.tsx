import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, ArrowLeft, RotateCcw, ChevronLeft, ChevronRight, Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Flashcard {
  front: string;
  back: string;
}

const FlashcardsPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [documents, setDocuments] = useState<any[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("documents").select("id, title, ai_notes, status")
      .eq("user_id", user.id)
      .eq("status", "completed")
      .order("created_at", { ascending: false })
      .then(({ data }) => setDocuments(data || []));
  }, [user]);

  const generateFlashcards = async (docId: string) => {
    setSelectedDoc(docId);
    setGenerating(true);
    setFlashcards([]);
    setCurrentIndex(0);
    setIsFlipped(false);

    try {
      const doc = documents.find(d => d.id === docId);
      const content = doc?.ai_notes || doc?.title || "General study material";

      const resp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-process`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ content: `Generate flashcards from this material. Return ONLY a JSON array of objects with "front" (question/term) and "back" (answer/definition) fields. Generate 10-15 flashcards.\n\nMaterial:\n${content}`, type: "notes" }),
      });

      if (!resp.ok) throw new Error("Failed");
      const data = await resp.json();
      const jsonMatch = data.result?.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        setFlashcards(JSON.parse(jsonMatch[0]));
        toast.success("Flashcards generated! 🃏");
      } else {
        throw new Error("No flashcards parsed");
      }
    } catch (e) {
      toast.error("Failed to generate flashcards");
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  const next = () => { setIsFlipped(false); setCurrentIndex(i => Math.min(i + 1, flashcards.length - 1)); };
  const prev = () => { setIsFlipped(false); setCurrentIndex(i => Math.max(i - 1, 0)); };

  return (
    <div className="min-h-screen bg-background">
      <motion.nav initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container mx-auto flex items-center gap-4 px-6 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-display font-bold text-foreground">Flashcards</span>
          </div>
        </div>
      </motion.nav>

      <div className="container mx-auto px-6 py-10 max-w-2xl">
        {flashcards.length === 0 ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h2 className="text-2xl font-display font-bold text-foreground mb-6">Choose a document to generate flashcards</h2>
            {documents.length === 0 ? (
              <div className="glass-card p-8 text-center">
                <p className="text-muted-foreground">No processed documents yet. Upload a document first!</p>
                <Button onClick={() => navigate("/upload")} className="mt-4 gradient-bg text-primary-foreground rounded-xl">
                  Upload Material
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {documents.map(doc => (
                  <motion.button
                    key={doc.id}
                    whileHover={{ x: 4 }}
                    onClick={() => generateFlashcards(doc.id)}
                    disabled={generating}
                    className="w-full glass-card-hover p-5 flex items-center justify-between text-left"
                  >
                    <span className="font-medium text-foreground">{doc.title}</span>
                    {generating && selectedDoc === doc.id ? (
                      <Loader2 className="w-5 h-5 animate-spin text-primary" />
                    ) : (
                      <Sparkles className="w-5 h-5 text-primary" />
                    )}
                  </motion.button>
                ))}
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="text-center mb-4">
              <span className="text-sm text-muted-foreground">{currentIndex + 1} / {flashcards.length}</span>
            </div>

            {/* Flashcard */}
            <div className="perspective-1000 mb-8" style={{ perspective: "1000px" }}>
              <motion.div
                onClick={() => setIsFlipped(!isFlipped)}
                animate={{ rotateY: isFlipped ? 180 : 0 }}
                transition={{ duration: 0.5 }}
                className="relative w-full h-72 cursor-pointer"
                style={{ transformStyle: "preserve-3d" }}
              >
                {/* Front */}
                <div className="absolute inset-0 glass-card p-8 flex items-center justify-center text-center backface-hidden" style={{ backfaceVisibility: "hidden" }}>
                  <p className="text-xl font-display font-semibold text-foreground">{flashcards[currentIndex]?.front}</p>
                </div>
                {/* Back */}
                <div className="absolute inset-0 glass-card p-8 flex items-center justify-center text-center" style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}>
                  <p className="text-lg text-foreground/90">{flashcards[currentIndex]?.back}</p>
                </div>
              </motion.div>
            </div>

            <p className="text-center text-xs text-muted-foreground mb-6">Tap to flip</p>

            <div className="flex items-center justify-center gap-4">
              <Button variant="outline" size="sm" onClick={prev} disabled={currentIndex === 0} className="rounded-xl border-border text-foreground">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={() => { setFlashcards([]); setSelectedDoc(null); }} className="rounded-xl border-border text-foreground">
                <RotateCcw className="w-4 h-4 mr-2" /> New Set
              </Button>
              <Button variant="outline" size="sm" onClick={next} disabled={currentIndex === flashcards.length - 1} className="rounded-xl border-border text-foreground">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default FlashcardsPage;
