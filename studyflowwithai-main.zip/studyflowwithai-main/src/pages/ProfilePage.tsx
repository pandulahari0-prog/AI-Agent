import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Brain, ArrowLeft, User, Camera, FileText, Clock, Trophy, Users, Sun, Moon, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTheme } from "next-themes";

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({ docs: 0, quizzes: 0, rooms: 0, studyTime: 0 });

  useEffect(() => {
    if (!user) return;
    const fetchProfile = async () => {
      const { data } = await supabase.from("profiles").select("*").eq("user_id", user.id).single();
      if (data) {
        setDisplayName(data.display_name || "");
        setAvatarUrl(data.avatar_url || "");
      }

      const { count: docCount } = await supabase.from("documents").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      const { count: quizCount } = await supabase.from("quiz_results").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      const { count: roomCount } = await supabase.from("room_members").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      setStats({ docs: docCount || 0, quizzes: quizCount || 0, rooms: roomCount || 0, studyTime: data?.total_study_time || 0 });
    };
    fetchProfile();
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("profiles").update({
        display_name: displayName,
        avatar_url: avatarUrl,
      }).eq("user_id", user.id);
      if (error) throw error;
      toast.success("Profile updated! ✨");
    } catch (e: any) {
      toast.error(e.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0] || !user) return;
    const file = e.target.files[0];
    const path = `${user.id}/avatar-${Date.now()}.${file.name.split('.').pop()}`;
    const { error } = await supabase.storage.from("study-materials").upload(path, file);
    if (error) { toast.error("Upload failed"); return; }
    const { data: { publicUrl } } = supabase.storage.from("study-materials").getPublicUrl(path);
    setAvatarUrl(publicUrl);
    toast.success("Avatar uploaded!");
  };

  const themeOptions = [
    { value: "light", icon: Sun, label: "Light" },
    { value: "dark", icon: Moon, label: "Dark" },
    { value: "system", icon: Monitor, label: "System" },
  ];

  const statCards = [
    { label: "Documents", value: stats.docs, icon: FileText },
    { label: "Study Hours", value: Math.round(stats.studyTime / 60), icon: Clock },
    { label: "Quizzes", value: stats.quizzes, icon: Trophy },
    { label: "Rooms", value: stats.rooms, icon: Users },
  ];

  return (
    <div className="min-h-screen bg-background">
      <motion.nav initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container mx-auto flex items-center gap-4 px-6 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-display font-bold text-foreground">Profile</span>
          </div>
        </div>
      </motion.nav>

      <div className="container mx-auto px-6 py-10 max-w-2xl">
        {/* Avatar & Name */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-8 mb-8">
          <div className="flex items-center gap-6 mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center overflow-hidden border-2 border-primary/30">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-8 h-8 text-muted-foreground" />
                )}
              </div>
              <label className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full gradient-bg flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity">
                <Camera className="w-3.5 h-3.5 text-primary-foreground" />
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
              </label>
            </div>
            <div>
              <h2 className="text-xl font-display font-bold text-foreground">{displayName || "Your Name"}</h2>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1 block">Display Name</label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Enter your name"
                className="rounded-xl bg-secondary/50 border-border text-foreground"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1 block">Avatar URL</label>
              <Input
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://..."
                className="rounded-xl bg-secondary/50 border-border text-foreground"
              />
            </div>
            <Button onClick={handleSave} disabled={saving} className="w-full rounded-xl gradient-bg text-primary-foreground font-semibold hover:opacity-90">
              {saving ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </motion.div>

        {/* Theme Toggle */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card p-8 mb-8">
          <h3 className="text-lg font-display font-semibold text-foreground mb-4">Theme</h3>
          <div className="grid grid-cols-3 gap-3">
            {themeOptions.map(opt => (
              <button
                key={opt.value}
                onClick={() => setTheme(opt.value)}
                className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${
                  theme === opt.value
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border bg-secondary/30 text-muted-foreground hover:border-primary/40"
                }`}
              >
                <opt.icon className="w-5 h-5" />
                <span className="text-sm font-medium">{opt.label}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card p-8">
          <h3 className="text-lg font-display font-semibold text-foreground mb-4">Study Statistics</h3>
          <div className="grid grid-cols-2 gap-4">
            {statCards.map(stat => (
              <div key={stat.label} className="p-4 rounded-2xl bg-secondary/30 border border-border text-center">
                <stat.icon className="w-6 h-6 mx-auto text-primary mb-2" />
                <div className="text-2xl font-display font-bold text-foreground">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfilePage;
