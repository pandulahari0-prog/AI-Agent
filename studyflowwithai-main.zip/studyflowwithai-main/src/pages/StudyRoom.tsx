import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, ArrowLeft, Users, Send, Clock, Play, Pause, MessageCircle, X, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const StudyRoom = () => {
  const navigate = useNavigate();
  const { roomCode } = useParams();
  const { user } = useAuth();
  const [room, setRoom] = useState<any>(null);
  const [members, setMembers] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [timerActive, setTimerActive] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [chatOpen, setChatOpen] = useState(true);

  // Fetch room
  useEffect(() => {
    const fetchRoom = async () => {
      const { data, error } = await supabase
        .from("rooms")
        .select("*")
        .eq("room_code", roomCode)
        .eq("is_active", true)
        .single();
      if (error || !data) {
        toast.error("Room not found");
        navigate("/dashboard");
        return;
      }
      setRoom(data);

      // Join room
      if (user) {
        await supabase.from("room_members").upsert({
          room_id: data.id,
          user_id: user.id,
          is_online: true,
        }, { onConflict: "room_id,user_id" });
      }
    };
    fetchRoom();
  }, [roomCode, user]);

  // Fetch members
  useEffect(() => {
    if (!room) return;
    const fetchMembers = async () => {
      const { data } = await supabase
        .from("room_members")
        .select("*, profiles:user_id(display_name, avatar_url)")
        .eq("room_id", room.id);
      setMembers(data || []);
    };
    fetchMembers();

    const channel = supabase
      .channel(`room-members-${room.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "room_members", filter: `room_id=eq.${room.id}` }, () => fetchMembers())
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [room]);

  // Fetch messages
  useEffect(() => {
    if (!room) return;
    const fetchMessages = async () => {
      const { data } = await supabase
        .from("room_messages")
        .select("*, profiles:user_id(display_name)")
        .eq("room_id", room.id)
        .order("created_at", { ascending: true })
        .limit(100);
      setMessages(data || []);
    };
    fetchMessages();

    const channel = supabase
      .channel(`room-messages-${room.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "room_messages", filter: `room_id=eq.${room.id}` }, (payload) => {
        // Refetch to get joined profile data
        fetchMessages();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [room]);

  // Scroll to bottom
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  // Pomodoro timer
  useEffect(() => {
    if (!room?.pomodoro_end_at) { setTimeLeft(null); return; }
    const end = new Date(room.pomodoro_end_at).getTime();
    const tick = () => {
      const left = Math.max(0, Math.floor((end - Date.now()) / 1000));
      setTimeLeft(left);
      setTimerActive(left > 0);
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [room?.pomodoro_end_at]);

  // Realtime room updates (timer)
  useEffect(() => {
    if (!room) return;
    const channel = supabase
      .channel(`room-${room.id}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "rooms", filter: `id=eq.${room.id}` }, (payload) => {
        setRoom(payload.new);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [room?.id]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !room || !user) return;
    await supabase.from("room_messages").insert({
      room_id: room.id,
      user_id: user.id,
      content: newMessage.trim(),
    });
    setNewMessage("");
  };

  const startTimer = async (minutes: number) => {
    if (!room) return;
    const endAt = new Date(Date.now() + minutes * 60 * 1000).toISOString();
    await supabase.from("rooms").update({ pomodoro_end_at: endAt, pomodoro_duration: minutes }).eq("id", room.id);
    toast.success(`${minutes} minute timer started!`);
  };

  const stopTimer = async () => {
    if (!room) return;
    await supabase.from("rooms").update({ pomodoro_end_at: null }).eq("id", room.id);
  };

  const leaveRoom = async () => {
    if (room && user) {
      await supabase.from("room_members").delete().eq("room_id", room.id).eq("user_id", user.id);
    }
    navigate("/dashboard");
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const isHost = room?.host_id === user?.id;
  const isLastTenSeconds = timeLeft !== null && timeLeft <= 10 && timeLeft > 0;

  if (!room) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}>
        <Brain className="w-8 h-8 text-primary" />
      </motion.div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Nav */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40"
      >
        <div className="container mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={leaveRoom} className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4 mr-1" /> Leave
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg gradient-bg flex items-center justify-center">
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-foreground">{room.name}</span>
              <span className="text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">{room.room_code}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Online members */}
            <div className="flex -space-x-2">
              {members.slice(0, 5).map((m, i) => (
                <motion.div
                  key={m.id}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: i * 0.1, type: "spring" }}
                  className="w-8 h-8 rounded-full bg-secondary border-2 border-background flex items-center justify-center"
                  title={(m.profiles as any)?.display_name || "Member"}
                >
                  <User className="w-4 h-4 text-muted-foreground" />
                </motion.div>
              ))}
            </div>
            <span className="text-xs text-muted-foreground">{members.length} online</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setChatOpen(!chatOpen)}
              className="text-muted-foreground hover:text-foreground md:hidden"
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.nav>

      <div className="flex-1 flex overflow-hidden">
        {/* Main area */}
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          {/* Pomodoro Timer */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center mb-8"
          >
            <motion.div
              className={`w-48 h-48 rounded-full border-4 flex items-center justify-center mx-auto mb-6 ${
                isLastTenSeconds ? "border-destructive" : timerActive ? "border-primary" : "border-border"
              }`}
              animate={isLastTenSeconds ? { scale: [1, 1.05, 1] } : {}}
              transition={isLastTenSeconds ? { duration: 0.5, repeat: Infinity } : {}}
            >
              {timeLeft !== null ? (
                <div>
                  <div className={`text-5xl font-display font-bold ${isLastTenSeconds ? "text-destructive" : "text-foreground"}`}>
                    {formatTime(timeLeft)}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {timeLeft === 0 ? "Time's up!" : "Focus time"}
                  </div>
                </div>
              ) : (
                <div className="text-center">
                  <Clock className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">No timer</p>
                </div>
              )}
            </motion.div>

            {isHost && (
              <div className="flex gap-2 justify-center flex-wrap">
                {!timerActive ? (
                  <>
                    {[5, 15, 25, 45].map((m) => (
                      <motion.div key={m} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => startTimer(m)}
                          className="rounded-xl border-border text-foreground hover:bg-secondary"
                        >
                          {m}m
                        </Button>
                      </motion.div>
                    ))}
                  </>
                ) : (
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={stopTimer}
                      className="rounded-xl border-destructive text-destructive hover:bg-destructive/10"
                    >
                      <Pause className="w-4 h-4 mr-1" /> Stop
                    </Button>
                  </motion.div>
                )}
              </div>
            )}
            {!isHost && !timerActive && (
              <p className="text-sm text-muted-foreground">Waiting for host to start timer...</p>
            )}
          </motion.div>
        </div>

        {/* Chat sidebar */}
        <AnimatePresence>
          {chatOpen && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="w-full md:w-80 lg:w-96 border-l border-border flex flex-col bg-background/50 backdrop-blur-xl absolute md:relative inset-0 md:inset-auto z-30"
            >
              <div className="flex items-center justify-between p-4 border-b border-border">
                <span className="font-semibold text-foreground text-sm">Room Chat</span>
                <button onClick={() => setChatOpen(false)} className="text-muted-foreground hover:text-foreground md:hidden">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`${msg.user_id === user?.id ? "text-right" : ""}`}
                  >
                    <span className="text-xs text-muted-foreground">
                      {(msg.profiles as any)?.display_name || "Anonymous"}
                    </span>
                    <div
                      className={`inline-block p-3 rounded-2xl text-sm max-w-[85%] ${
                        msg.user_id === user?.id
                          ? "gradient-bg text-primary-foreground rounded-br-md ml-auto"
                          : "bg-secondary text-foreground rounded-bl-md"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </motion.div>
                ))}
                <div ref={chatEndRef} />
              </div>

              <div className="p-3 border-t border-border">
                <form onSubmit={(e) => { e.preventDefault(); sendMessage(); }} className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 py-2 rounded-xl bg-secondary/50 border-border text-foreground placeholder:text-muted-foreground text-sm"
                  />
                  <Button type="submit" size="sm" className="rounded-xl gradient-bg text-primary-foreground">
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default StudyRoom;
