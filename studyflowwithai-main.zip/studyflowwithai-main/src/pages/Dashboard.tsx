import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  BookOpen, Brain, Clock, FileText, Plus, Users, Trophy, Upload, ArrowRight, LogOut, User, Layers,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import LusyChat from "@/components/LusyChat";

const quickActions = [
  { label: "Upload Material", icon: Upload, path: "/upload", gradient: true },
  { label: "Create Room", icon: Plus, path: "/rooms/create", gradient: false },
  { label: "Join Room", icon: Users, path: "/rooms/join", gradient: false },
  { label: "Flashcards", icon: Layers, path: "/flashcards", gradient: false },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

const AnimatedCounter = ({ value, suffix = "" }: { value: number; suffix?: string }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = Math.ceil(value / 75);
    const timer = setInterval(() => {
      start += step;
      if (start >= value) { setCount(value); clearInterval(timer); }
      else setCount(start);
    }, 16);
    return () => clearInterval(timer);
  }, [value]);
  return <>{count}{suffix}</>;
};

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const [documents, setDocuments] = useState<any[]>([]);
  const [stats, setStats] = useState({ docs: 0, quizzes: 0, rooms: 0 });

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: docs } = await supabase.from("documents").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(5);
      setDocuments(docs || []);

      const { count: docCount } = await supabase.from("documents").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      const { count: quizCount } = await supabase.from("quiz_results").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      const { count: roomCount } = await supabase.from("room_members").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      setStats({ docs: docCount || 0, quizzes: quizCount || 0, rooms: roomCount || 0 });
    };
    fetchData();
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const statCards = [
    { label: "Documents", value: stats.docs, icon: FileText, color: "from-primary to-primary" },
    { label: "Study Hours", value: 0, icon: Clock, color: "from-accent to-accent" },
    { label: "Quizzes Taken", value: stats.quizzes, icon: Trophy, color: "from-primary to-accent" },
    { label: "Study Rooms", value: stats.rooms, icon: Users, color: "from-accent to-primary" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <motion.nav initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container mx-auto flex items-center justify-between px-6 py-4">
          <motion.div className="flex items-center gap-2" whileHover={{ scale: 1.03 }}>
            <motion.div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center" animate={{ rotate: [0, 5, -5, 0] }} transition={{ duration: 4, repeat: Infinity }}>
              <Brain className="w-5 h-5 text-primary-foreground" />
            </motion.div>
            <span className="text-lg font-display font-bold text-foreground">StudyFlow AI</span>
          </motion.div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground" onClick={() => navigate("/profile")}>
              <User className="w-4 h-4 mr-2" /> Profile
            </Button>
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" /> Sign Out
            </Button>
          </div>
        </div>
      </motion.nav>

      <div className="container mx-auto px-6 py-10">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Welcome back 👋</h1>
          <p className="text-muted-foreground text-lg">Ready for a productive study session?</p>
        </motion.div>

        <motion.div initial="hidden" animate="visible" className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {statCards.map((stat, i) => (
            <motion.div key={stat.label} variants={fadeUp} custom={i} whileHover={{ y: -4, scale: 1.02 }} transition={{ type: "spring", stiffness: 300 }} className="glass-card-hover p-6 cursor-default">
              <motion.div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-4 opacity-80`} whileHover={{ rotate: 10, scale: 1.1 }}>
                <stat.icon className="w-5 h-5 text-primary-foreground" />
              </motion.div>
              <div className="text-3xl font-display font-bold text-foreground mb-1">
                <AnimatedCounter value={stat.value} />
              </div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div initial="hidden" animate="visible" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {quickActions.map((action, i) => (
            <motion.div key={action.label} variants={fadeUp} custom={i + 4} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button variant="outline" className={`w-full h-auto py-6 rounded-2xl border-border transition-all duration-300 flex items-center gap-3 ${action.gradient ? "gradient-bg text-primary-foreground border-0 hover:opacity-90 glow-primary" : "bg-secondary/50 text-foreground hover:bg-secondary"}`} onClick={() => navigate(action.path)}>
                <action.icon className="w-5 h-5 shrink-0" />
                <span className="font-semibold">{action.label}</span>
              </Button>
            </motion.div>
          ))}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-display font-semibold text-foreground">Recent Uploads</h2>
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground" onClick={() => navigate("/upload")}>
              View All <ArrowRight className="ml-1 w-4 h-4" />
            </Button>
          </div>
          {documents.length === 0 ? (
            <div className="glass-card p-8 text-center">
              <Upload className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground">No documents yet. Upload your first study material!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {documents.map((doc, i) => (
                <motion.div key={doc.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.7 + i * 0.1 }} whileHover={{ x: 4 }} className="glass-card-hover p-5 flex items-center justify-between cursor-pointer" onClick={() => navigate(`/upload?doc=${doc.id}`)}>
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                      <BookOpen className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{doc.title}</div>
                      <div className="text-sm text-muted-foreground">{doc.file_type} · {doc.status}</div>
                    </div>
                  </div>
                  <span className="text-sm text-muted-foreground">{new Date(doc.created_at).toLocaleDateString()}</span>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>

      <LusyChat />
    </div>
  );
};

export default Dashboard;
