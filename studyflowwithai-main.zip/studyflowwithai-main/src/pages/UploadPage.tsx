import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Upload, FileText, Image, File, X, Sparkles, ArrowLeft, BookOpen, MessageSquare, HelpCircle, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import ReactMarkdown from "react-markdown";
import confetti from "canvas-confetti";

const UploadPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<"notes" | "summary" | "quiz">("notes");
  const [aiNotes, setAiNotes] = useState("");
  const [aiSummary, setAiSummary] = useState("");
  const [aiQuiz, setAiQuiz] = useState<any[]>([]);
  const [docId, setDocId] = useState<string | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState<number | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setIsDragging(true);
    else if (e.type === "dragleave") setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const dropped = Array.from(e.dataTransfer.files);
    if (dropped.length > 0) { setFiles(prev => [...prev, ...dropped]); toast.success(`${dropped.length} file(s) added!`); }
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selected = Array.from(e.target.files);
      setFiles(prev => [...prev, ...selected]);
      toast.success(`${selected.length} file(s) added!`);
    }
  };

  const removeFile = (index: number) => setFiles(prev => prev.filter((_, i) => i !== index));

  const getFileIcon = (file: File) => {
    if (file.type.includes("pdf")) return FileText;
    if (file.type.includes("image")) return Image;
    return File;
  };

  const callAI = async (content: string, type: string) => {
    const resp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-process`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
      },
      body: JSON.stringify({ content, type }),
    });
    if (!resp.ok) throw new Error("AI processing failed");
    const data = await resp.json();
    return data.result;
  };

  const handleProcess = async () => {
    if (files.length === 0 || !user) { toast.error("Please upload at least one file!"); return; }
    setProcessing(true);

    try {
      // Read file content (text-based)
      let textContent = "";
      for (const file of files) {
        if (file.type.includes("text") || file.name.endsWith(".txt") || file.name.endsWith(".md")) {
          textContent += await file.text() + "\n\n";
        } else {
          textContent += `[File: ${file.name} (${file.type})] — Content extraction from this file type is limited. Process the filename and any available metadata.\n\n`;
        }
      }

      if (!textContent.trim()) {
        textContent = `Study material from files: ${files.map(f => f.name).join(", ")}. Generate sample educational content for demonstration.`;
      }

      // Upload to storage
      const filePath = `${user.id}/${Date.now()}-${files[0].name}`;
      await supabase.storage.from("study-materials").upload(filePath, files[0]);

      // Create document record
      const { data: doc } = await supabase.from("documents").insert({
        user_id: user.id,
        title: files[0].name.replace(/\.[^/.]+$/, ""),
        file_url: filePath,
        file_type: files[0].type,
        status: "processing",
      }).select().single();

      if (doc) setDocId(doc.id);

      // Process with AI in parallel
      const [notes, summary, quizRaw] = await Promise.all([
        callAI(textContent, "notes"),
        callAI(textContent, "summary"),
        callAI(textContent, "quiz"),
      ]);

      setAiNotes(notes);
      setAiSummary(summary);

      // Parse quiz JSON
      let quiz: any[] = [];
      try {
        const jsonMatch = quizRaw.match(/\[[\s\S]*\]/);
        if (jsonMatch) quiz = JSON.parse(jsonMatch[0]);
      } catch { quiz = []; }
      setAiQuiz(quiz);

      // Save to database
      if (doc) {
        await supabase.from("documents").update({
          ai_notes: notes,
          ai_summary: summary,
          ai_quiz: quiz,
          status: "completed",
        }).eq("id", doc.id);
      }

      toast.success("AI processing complete! 🎉");
    } catch (e) {
      console.error(e);
      toast.error("Processing failed. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const submitQuiz = async () => {
    let correct = 0;
    aiQuiz.forEach((q, i) => {
      if (quizAnswers[i] === q.correct_answer) correct++;
    });
    const score = Math.round((correct / aiQuiz.length) * 100);
    setQuizScore(score);
    setQuizSubmitted(true);

    if (score >= 80) confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 } });

    if (user && docId) {
      await supabase.from("quiz_results").insert({
        user_id: user.id,
        document_id: docId,
        score: correct,
        total: aiQuiz.length,
        answers: quizAnswers,
      });
    }
  };

  const tabs = [
    { id: "notes" as const, label: "Full Notes", icon: BookOpen },
    { id: "summary" as const, label: "Summary", icon: MessageSquare },
    { id: "quiz" as const, label: "Quiz", icon: HelpCircle },
  ];

  const hasResults = aiNotes || aiSummary || aiQuiz.length > 0;

  return (
    <div className="min-h-screen bg-background">
      <motion.nav initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container mx-auto flex items-center gap-4 px-6 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-display font-bold text-foreground">Upload Material</span>
          </div>
        </div>
      </motion.nav>

      <div className="container mx-auto px-6 py-10 max-w-3xl">
        <AnimatePresence mode="wait">
          {!hasResults ? (
            <motion.div key="upload" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <motion.div
                onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}
                animate={isDragging ? { scale: 1.02 } : { scale: 1 }}
                className={`glass-card p-12 text-center cursor-pointer border-2 border-dashed transition-colors ${isDragging ? "border-primary bg-primary/5" : "border-glass-border hover:border-primary/40"}`}
                onClick={() => document.getElementById("file-input")?.click()}
              >
                <input id="file-input" type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.heic,.webp,.txt,.docx" className="hidden" onChange={handleFileInput} />
                <motion.div animate={isDragging ? { y: -10 } : { y: 0 }}>
                  <div className="w-16 h-16 mx-auto rounded-2xl gradient-bg flex items-center justify-center mb-6 glow-primary">
                    <Upload className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <h3 className="text-xl font-display font-semibold text-foreground mb-2">
                    {isDragging ? "Drop your files here!" : "Drag & drop your study materials"}
                  </h3>
                  <p className="text-muted-foreground mb-4">PDF, Images (JPG, PNG, WEBP), TXT, DOCX</p>
                  <Button variant="outline" className="rounded-2xl border-border text-foreground hover:bg-secondary">Browse Files</Button>
                </motion.div>
              </motion.div>

              <AnimatePresence>
                {files.length > 0 && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 space-y-3">
                    {files.map((file, i) => {
                      const Icon = getFileIcon(file);
                      return (
                        <motion.div key={`${file.name}-${i}`} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} className="glass-card p-4 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center"><Icon className="w-5 h-5 text-primary" /></div>
                            <div>
                              <p className="text-sm font-medium text-foreground">{file.name}</p>
                              <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                            </div>
                          </div>
                          <button onClick={() => removeFile(i)} className="text-muted-foreground hover:text-destructive transition-colors"><X className="w-4 h-4" /></button>
                        </motion.div>
                      );
                    })}
                    <Button onClick={handleProcess} disabled={processing} className="w-full py-6 rounded-2xl gradient-bg text-primary-foreground font-semibold text-base hover:opacity-90 glow-primary mt-4">
                      {processing ? (
                        <div className="flex items-center gap-3">
                          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}><Sparkles className="w-5 h-5" /></motion.div>
                          AI is processing...
                        </div>
                      ) : (<><Sparkles className="w-5 h-5 mr-2" />Process with AI</>)}
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {processing && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-8 glass-card p-8 text-center">
                    <div className="flex items-center justify-center gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <motion.div key={i} className="w-1.5 rounded-full gradient-bg" animate={{ height: [12, 28, 12] }} transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }} />
                      ))}
                    </div>
                    <p className="text-foreground font-medium">Analyzing your materials...</p>
                    <p className="text-sm text-muted-foreground mt-1">Generating notes, summary, and quiz questions</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : (
            <motion.div key="results" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <div className="flex gap-2 mb-6">
                {tabs.map(tab => (
                  <Button key={tab.id} variant="outline" onClick={() => setActiveTab(tab.id)} className={`flex-1 py-5 rounded-2xl font-semibold transition-all ${activeTab === tab.id ? "gradient-bg text-primary-foreground border-0 glow-primary" : "bg-secondary/50 text-foreground border-border hover:bg-secondary"}`}>
                    <tab.icon className="w-4 h-4 mr-2" />{tab.label}
                  </Button>
                ))}
              </div>

              <AnimatePresence mode="wait">
                <motion.div key={activeTab} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="glass-card p-8">
                  {activeTab === "notes" && (
                    <div className="prose prose-invert max-w-none">
                      <h2 className="text-2xl font-display font-bold text-foreground mb-4">📝 AI-Generated Notes</h2>
                      <div className="text-foreground/90">
                        <ReactMarkdown>{aiNotes}</ReactMarkdown>
                      </div>
                    </div>
                  )}
                  {activeTab === "summary" && (
                    <div>
                      <h2 className="text-2xl font-display font-bold text-foreground mb-4">📋 Summary</h2>
                      <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiSummary}</p>
                    </div>
                  )}
                  {activeTab === "quiz" && (
                    <div>
                      <h2 className="text-2xl font-display font-bold text-foreground mb-6">🧠 Quiz</h2>
                      {quizSubmitted && quizScore !== null && (
                        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className={`p-6 rounded-2xl mb-6 text-center ${quizScore >= 80 ? "bg-emerald-500/10 border border-emerald-500/30" : "bg-amber-500/10 border border-amber-500/30"}`}>
                          <div className="text-4xl font-display font-bold text-foreground mb-2">{quizScore}%</div>
                          <p className="text-muted-foreground">{quizScore >= 80 ? "🎉 Excellent work!" : "💪 Keep studying, you'll get there!"}</p>
                        </motion.div>
                      )}
                      <div className="space-y-6">
                        {aiQuiz.map((q: any, i: number) => (
                          <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="p-5 rounded-2xl bg-secondary/30 border border-border">
                            <p className="font-medium text-foreground mb-3">Q{i + 1}. {q.question}</p>
                            {q.options && q.options.length > 0 ? (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {q.options.map((opt: string, j: number) => {
                                  const selected = quizAnswers[i] === opt;
                                  const isCorrect = quizSubmitted && opt === q.correct_answer;
                                  const isWrong = quizSubmitted && selected && opt !== q.correct_answer;
                                  return (
                                    <button
                                      key={j}
                                      onClick={() => !quizSubmitted && setQuizAnswers(prev => ({ ...prev, [i]: opt }))}
                                      className={`text-left p-3 rounded-xl border text-sm transition-all ${
                                        isCorrect ? "border-emerald-500 bg-emerald-500/10 text-emerald-400" :
                                        isWrong ? "border-destructive bg-destructive/10 text-destructive" :
                                        selected ? "border-primary bg-primary/10 text-foreground" :
                                        "border-border bg-secondary/50 text-muted-foreground hover:border-primary/50 hover:text-foreground"
                                      }`}
                                    >
                                      {String.fromCharCode(65 + j)}. {opt}
                                    </button>
                                  );
                                })}
                              </div>
                            ) : (
                              <Input
                                placeholder="Type your answer..."
                                value={quizAnswers[i] || ""}
                                onChange={(e) => !quizSubmitted && setQuizAnswers(prev => ({ ...prev, [i]: e.target.value }))}
                                className="rounded-xl bg-secondary/50 border-border text-foreground"
                                disabled={quizSubmitted}
                              />
                            )}
                            {quizSubmitted && q.explanation && (
                              <p className="text-xs text-muted-foreground mt-2 italic">💡 {q.explanation}</p>
                            )}
                          </motion.div>
                        ))}
                      </div>
                      {!quizSubmitted && aiQuiz.length > 0 && (
                        <Button onClick={submitQuiz} className="w-full mt-6 py-5 rounded-2xl gradient-bg text-primary-foreground font-semibold glow-primary">
                          <Check className="w-5 h-5 mr-2" />Submit Answers
                        </Button>
                      )}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default UploadPage;
