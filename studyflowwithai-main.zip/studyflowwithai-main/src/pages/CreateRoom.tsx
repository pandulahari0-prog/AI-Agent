import { useState } from "react";
import { motion } from "framer-motion";
import { Brain, ArrowLeft, Copy, Users, Palette, Check, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const gradients = [
  "from-primary to-accent",
  "from-pink-500 to-rose-500",
  "from-emerald-500 to-teal-500",
  "from-amber-500 to-orange-500",
  "from-violet-500 to-purple-500",
  "from-sky-500 to-blue-500",
];

const CreateRoom = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [roomName, setRoomName] = useState("");
  const [selectedGradient, setSelectedGradient] = useState(0);
  const [maxParticipants, setMaxParticipants] = useState(10);
  const [created, setCreated] = useState(false);
  const [roomCode, setRoomCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  const generateCode = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  };

  const handleCreate = async () => {
    if (!roomName.trim()) { toast.error("Please enter a room name!"); return; }
    if (!user) { toast.error("Please sign in first"); return; }
    setLoading(true);
    try {
      const code = generateCode();
      const { error } = await supabase.from("rooms").insert({
        host_id: user.id,
        name: roomName.trim(),
        room_code: code,
        theme: gradients[selectedGradient],
        max_participants: maxParticipants,
      });
      if (error) throw error;
      setRoomCode(code);
      setCreated(true);
      toast.success("Study room created! 🎉");
    } catch (e: any) {
      toast.error(e.message || "Failed to create room");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(roomCode);
    setCopied(true);
    toast.success("Room code copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {[...Array(8)].map((_, i) => (
        <motion.div key={i} className="absolute w-1 h-1 rounded-full gradient-bg opacity-20" animate={{ y: [0, -40, 0], opacity: [0.1, 0.4, 0.1] }} transition={{ duration: 4 + i * 0.7, repeat: Infinity, delay: i * 0.5 }} style={{ top: `${15 + i * 10}%`, left: `${5 + i * 12}%` }} />
      ))}

      <motion.nav initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container mx-auto flex items-center gap-4 px-6 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground hover:text-foreground"><ArrowLeft className="w-4 h-4 mr-2" /> Back</Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center"><Brain className="w-5 h-5 text-primary-foreground" /></div>
            <span className="text-lg font-display font-bold text-foreground">Create Study Room</span>
          </div>
        </div>
      </motion.nav>

      <div className="container mx-auto px-6 py-10 max-w-lg">
        {!created ? (
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-8">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.2 }} className="w-16 h-16 mx-auto rounded-2xl gradient-bg flex items-center justify-center mb-6 glow-primary">
              <Users className="w-8 h-8 text-primary-foreground" />
            </motion.div>
            <h2 className="text-2xl font-display font-bold text-foreground text-center mb-8">Set up your study room</h2>
            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Room Name</label>
                <Input value={roomName} onChange={(e) => setRoomName(e.target.value)} placeholder="e.g. Calc Study Group" className="py-5 rounded-2xl bg-secondary/50 border-border text-foreground placeholder:text-muted-foreground" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-3 block flex items-center gap-2"><Palette className="w-4 h-4 text-primary" /> Room Theme</label>
                <div className="grid grid-cols-6 gap-2">
                  {gradients.map((g, i) => (
                    <motion.button key={i} whileHover={{ scale: 1.15 }} whileTap={{ scale: 0.95 }} onClick={() => setSelectedGradient(i)} className={`h-10 rounded-xl bg-gradient-to-r ${g} transition-all ${selectedGradient === i ? "ring-2 ring-foreground ring-offset-2 ring-offset-background" : "opacity-60 hover:opacity-100"}`} />
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Max Participants</label>
                <div className="flex items-center gap-3">
                  {[5, 10, 15, 20].map(n => (
                    <motion.button key={n} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => setMaxParticipants(n)} className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all ${maxParticipants === n ? "gradient-bg text-primary-foreground glow-primary" : "bg-secondary/50 text-muted-foreground border border-border hover:text-foreground"}`}>{n}</motion.button>
                  ))}
                </div>
              </div>
              <Button onClick={handleCreate} disabled={loading} className="w-full py-6 rounded-2xl gradient-bg text-primary-foreground font-semibold text-base hover:opacity-90 glow-primary">
                {loading ? <Sparkles className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-5 h-5 mr-2" />Create Room</>}
              </Button>
            </div>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="glass-card p-8 text-center">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.1 }} className="w-20 h-20 mx-auto rounded-3xl gradient-bg flex items-center justify-center mb-6 glow-primary">
              <Check className="w-10 h-10 text-primary-foreground" />
            </motion.div>
            <h2 className="text-2xl font-display font-bold text-foreground mb-2">Room Created! 🎉</h2>
            <p className="text-muted-foreground mb-6">Share this code with your friends to join</p>
            <motion.div animate={{ scale: [1, 1.02, 1] }} transition={{ duration: 2, repeat: Infinity }} className="bg-secondary/50 border border-border rounded-2xl p-6 mb-6">
              <p className="text-sm text-muted-foreground mb-2">Room Code</p>
              <p className="text-4xl font-display font-bold gradient-text tracking-[0.3em]">{roomCode}</p>
            </motion.div>
            <div className="flex gap-3">
              <Button onClick={handleCopy} variant="outline" className="flex-1 py-5 rounded-2xl border-border text-foreground hover:bg-secondary">
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}{copied ? "Copied!" : "Copy Code"}
              </Button>
              <Button onClick={() => navigate(`/rooms/${roomCode}`)} className="flex-1 py-5 rounded-2xl gradient-bg text-primary-foreground font-semibold hover:opacity-90">
                Enter Room
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default CreateRoom;
