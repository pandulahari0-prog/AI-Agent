import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen, Brain, MessageCircle, Users, Sparkles, Zap, Shield, Layers } from "lucide-react";
import { useNavigate } from "react-router-dom";

const features = [
  {
    icon: BookOpen,
    title: "Upload → AI Notes",
    description: "Drop any PDF, photo, or doc. Get structured notes, summaries, and smart quizzes in seconds.",
  },
  {
    icon: Brain,
    title: "Lusy AI Tutor",
    description: "Voice-enabled chat tutor that knows your material. Ask anything, get patient, clear explanations.",
  },
  {
    icon: Users,
    title: "Study Rooms",
    description: "Create private rooms with invite codes. Shared timers, live chat, and synchronized study sessions.",
  },
  {
    icon: Layers,
    title: "AI Flashcards",
    description: "Auto-generated flashcards from your documents. Flip, memorize, and master any topic effortlessly.",
  },
];

const statsData = [
  { value: "50K+", label: "Active Students", icon: Users },
  { value: "2M+", label: "Notes Generated", icon: Sparkles },
  { value: "98%", label: "Pass Rate Boost", icon: Zap },
  { value: "256-bit", label: "Encrypted", icon: Shield },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.6, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background overflow-hidden mesh-gradient">
      {/* Animated background particles */}
      {[...Array(16)].map((_, i) => (
        <motion.div
          key={i}
          className="fixed rounded-full pointer-events-none"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            width: `${2 + Math.random() * 4}px`,
            height: `${2 + Math.random() * 4}px`,
            background: i % 3 === 0
              ? `hsl(263 70% 58% / 0.4)`
              : i % 3 === 1
              ? `hsl(187 85% 53% / 0.3)`
              : `hsl(240 60% 50% / 0.3)`,
          }}
          animate={{
            y: [0, -80, 0],
            x: [0, (i % 2 === 0 ? 40 : -40), 0],
            opacity: [0, 0.6, 0],
            scale: [0.5, 1.5, 0.5],
          }}
          transition={{ duration: 6 + i * 0.8, repeat: Infinity, ease: "easeInOut", delay: i * 0.5 }}
        />
      ))}

      {/* Navbar */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="fixed top-0 inset-x-0 z-50 border-b border-border/50 bg-background/60 backdrop-blur-xl"
      >
        <div className="container mx-auto flex items-center justify-between px-6 py-4">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.03 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <motion.div
              className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center glow-primary"
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <Brain className="w-5 h-5 text-primary-foreground" />
            </motion.div>
            <span className="text-lg font-display font-bold text-foreground">StudyFlow AI</span>
          </motion.div>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => navigate("/auth")}
            >
              Sign In
            </Button>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                className="gradient-bg text-primary-foreground font-semibold px-6 rounded-2xl hover:opacity-90 transition-opacity glow-primary"
                onClick={() => navigate("/auth")}
              >
                Get Started
              </Button>
            </motion.div>
          </div>
        </div>
      </motion.nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 aurora-bg">
        {/* Animated glow orbs */}
        <motion.div
          className="hero-glow top-1/4 left-1/4 -translate-x-1/2"
          style={{ background: `hsl(263 70% 58%)` }}
          animate={{ scale: [1, 1.3, 1], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="hero-glow top-1/3 right-1/4 translate-x-1/2"
          style={{ background: `hsl(187 85% 53%)` }}
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.08, 0.16, 0.08] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="hero-glow bottom-1/4 left-1/2 -translate-x-1/2"
          style={{ background: `hsl(240 60% 45%)` }}
          animate={{ scale: [1, 1.4, 1], opacity: [0.05, 0.12, 0.05] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
        />

        <div className="relative z-10 container mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-border bg-secondary/50 backdrop-blur-sm mb-8"
            >
              <motion.span
                className="w-2 h-2 rounded-full gradient-bg"
                animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
              <span className="text-sm text-muted-foreground">AI-Powered Study Platform</span>
            </motion.div>

            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-bold leading-[1.05] tracking-tight mb-6">
              <motion.span
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                className="text-foreground inline-block"
              >
                Study Alone.
              </motion.span>
              <br />
              <motion.span
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.6 }}
                className="gradient-text inline-block"
              >
                Win Together.
              </motion.span>
            </h1>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="max-w-2xl mx-auto text-lg sm:text-xl text-muted-foreground mb-10 leading-relaxed"
            >
              Upload any study material, get AI-generated notes & quizzes, chat with Lusy your personal tutor,
              and join collaborative study rooms with friends.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  className="gradient-bg text-primary-foreground font-semibold text-lg px-8 py-6 rounded-2xl glow-primary hover:opacity-90 transition-all"
                  onClick={() => navigate("/auth")}
                >
                  Start Studying Free
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-border text-foreground font-semibold text-lg px-8 py-6 rounded-2xl hover:bg-secondary transition-all gradient-border"
                >
                  Watch Demo
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2">
            <motion.div
              className="w-1.5 h-1.5 rounded-full bg-primary/60"
              animate={{ y: [0, 12, 0], opacity: [1, 0.3, 1] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            />
          </div>
        </motion.div>
      </section>

      {/* Stats Bar */}
      <section className="relative z-10 py-16 px-6 border-y border-border/50">
        <div className="container mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8"
          >
            {statsData.map((stat, i) => (
              <motion.div
                key={stat.label}
                variants={fadeUp}
                custom={i}
                className="text-center"
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-10 h-10 mx-auto rounded-xl gradient-bg flex items-center justify-center mb-3 glow-primary"
                >
                  <stat.icon className="w-5 h-5 text-primary-foreground" />
                </motion.div>
                <div className="text-2xl md:text-3xl font-display font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="relative z-10 py-32 px-6">
        <div className="container mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <motion.h2
              variants={fadeUp}
              custom={0}
              className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-foreground mb-4"
            >
              Everything you need to{" "}
              <span className="gradient-text">ace your studies</span>
            </motion.h2>
            <motion.p
              variants={fadeUp}
              custom={1}
              className="text-lg text-muted-foreground max-w-xl mx-auto"
            >
              Powered by AI. Built for students. Designed for success.
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                variants={fadeUp}
                custom={i + 2}
                whileHover={{ y: -8, scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="glass-card-hover p-8 group cursor-pointer shimmer"
              >
                <motion.div
                  className="w-12 h-12 rounded-2xl gradient-bg flex items-center justify-center mb-5 glow-primary"
                  whileHover={{ rotate: 10, scale: 1.15 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <feature.icon className="w-6 h-6 text-primary-foreground" />
                </motion.div>
                <h3 className="text-xl font-display font-semibold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* How it works */}
      <section className="relative z-10 py-32 px-6">
        <div className="container mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <motion.h2 variants={fadeUp} custom={0} className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
              How it <span className="gradient-text">works</span>
            </motion.h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { step: "01", title: "Upload", desc: "Drop your PDFs, notes, or images" },
              { step: "02", title: "AI Processes", desc: "Get notes, summaries, quizzes & flashcards" },
              { step: "03", title: "Study & Share", desc: "Study solo or invite friends to a room" },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 0.5 }}
                className="text-center"
              >
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  className="text-5xl font-display font-bold gradient-text mb-4"
                >
                  {item.step}
                </motion.div>
                <h3 className="text-xl font-display font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 py-32 px-6">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass-card p-12 md:p-20 text-center relative overflow-hidden"
          >
            <motion.div
              className="hero-glow -top-20 left-1/2 -translate-x-1/2 opacity-20"
              style={{ background: `hsl(263 70% 58%)` }}
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 4, repeat: Infinity }}
            />
            <motion.div
              className="hero-glow -bottom-20 left-1/3 opacity-10"
              style={{ background: `hsl(187 85% 53%)` }}
              animate={{ scale: [1.2, 1, 1.2] }}
              transition={{ duration: 5, repeat: Infinity }}
            />
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-foreground mb-6 relative z-10">
              Ready to transform how you study?
            </h2>
            <p className="text-lg text-muted-foreground max-w-lg mx-auto mb-8 relative z-10">
              Join thousands of students using AI to study smarter, not harder.
            </p>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="relative z-10">
              <Button
                size="lg"
                className="gradient-bg text-primary-foreground font-semibold text-lg px-10 py-6 rounded-2xl glow-primary hover:opacity-90 transition-all"
                onClick={() => navigate("/auth")}
              >
                Get Started — It's Free
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-6 relative z-10">
        <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg gradient-bg flex items-center justify-center">
              <Brain className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-semibold text-foreground">StudyFlow AI</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2026 StudyFlow AI. Study smarter together.</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
