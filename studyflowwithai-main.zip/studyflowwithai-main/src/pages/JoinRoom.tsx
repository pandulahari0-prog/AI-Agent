import { useState } from "react";
import { motion } from "framer-motion";
import { Brain, ArrowLeft, Users, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const JoinRoom = () => {
  const navigate = useNavigate();
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [joining, setJoining] = useState(false);

  const handleInput = (index: number, value: string) => {
    if (value.length > 1) return;
    const upper = value.toUpperCase();
    const newCode = [...code];
    newCode[index] = upper;
    setCode(newCode);
    if (upper && index < 5) document.getElementById(`code-${index + 1}`)?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !code[index] && index > 0) document.getElementById(`code-${index - 1}`)?.focus();
    if (e.key === "Enter") handleJoin();
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
    const newCode = [...code];
    for (let i = 0; i < 6; i++) newCode[i] = pasted[i] || "";
    setCode(newCode);
    if (pasted.length >= 6) document.getElementById("code-5")?.focus();
  };

  const handleJoin = async () => {
    const full = code.join("");
    if (full.length < 6) { toast.error("Please enter the complete 6-character code!"); return; }
    setJoining(true);
    try {
      const { data: room, error } = await supabase.from("rooms").select("*").eq("room_code", full).eq("is_active", true).single();
      if (error || !room) { toast.error("Room not found or inactive"); return; }
      toast.success("Joining study room! 🎉");
      navigate(`/rooms/${full}`);
    } catch {
      toast.error("Failed to join room");
    } finally {
      setJoining(false);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {[...Array(6)].map((_, i) => (
        <motion.div key={i} className="absolute w-1.5 h-1.5 rounded-full gradient-bg opacity-15" animate={{ y: [0, -50, 0], opacity: [0.05, 0.3, 0.05] }} transition={{ duration: 5 + i, repeat: Infinity, delay: i * 0.8 }} style={{ top: `${20 + i * 12}%`, left: `${8 + i * 16}%` }} />
      ))}

      <motion.nav initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container mx-auto flex items-center gap-4 px-6 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground hover:text-foreground"><ArrowLeft className="w-4 h-4 mr-2" /> Back</Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center"><Brain className="w-5 h-5 text-primary-foreground" /></div>
            <span className="text-lg font-display font-bold text-foreground">Join Study Room</span>
          </div>
        </div>
      </motion.nav>

      <div className="container mx-auto px-6 py-16 max-w-lg">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-8 text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.2 }} className="w-16 h-16 mx-auto rounded-2xl gradient-bg flex items-center justify-center mb-6 glow-primary">
            <Users className="w-8 h-8 text-primary-foreground" />
          </motion.div>
          <h2 className="text-2xl font-display font-bold text-foreground mb-2">Enter Room Code</h2>
          <p className="text-muted-foreground mb-8">Ask your friend for the 6-character code</p>
          <div className="flex justify-center gap-3 mb-8" onPaste={handlePaste}>
            {code.map((char, i) => (
              <motion.input key={i} id={`code-${i}`} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.08 }} type="text" maxLength={1} value={char} onChange={(e) => handleInput(i, e.target.value)} onKeyDown={(e) => handleKeyDown(i, e)} className="w-12 h-14 sm:w-14 sm:h-16 text-center text-2xl font-display font-bold rounded-xl bg-secondary/50 border-2 border-border text-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all uppercase" />
            ))}
          </div>
          <Button onClick={handleJoin} disabled={joining} className="w-full py-6 rounded-2xl gradient-bg text-primary-foreground font-semibold text-base hover:opacity-90 glow-primary">
            {joining ? <><Loader2 className="w-5 h-5 animate-spin mr-2" />Joining...</> : <>Join Room<ArrowRight className="ml-2 w-5 h-5" /></>}
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default JoinRoom;
